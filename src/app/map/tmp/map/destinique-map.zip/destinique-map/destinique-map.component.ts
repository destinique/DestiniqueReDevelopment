import { Component } from '@angular/core';

@Component({
  selector: 'app-destinique-map',
  templateUrl: './destinique-map.component.html',
  styleUrls: ['./destinique-map.component.scss']
})
export class DestiniqueMapComponent {

}
